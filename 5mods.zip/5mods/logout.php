<?php
setcookie('login', null, -1); 
header("Location:http://localhost/5mods/index.php");
?>